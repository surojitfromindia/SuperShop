create function gen_user_public_id() returns text
    language plpgsql
as
$$
DECLARE
    seq_val bigint;
BEGIN
    seq_val := nextval('user_public_seq');
    RETURN to_char(NOW(), 'YYYYMMDD')||lpad(seq_val::text, 6, '0');
END;
$$;

alter function gen_user_public_id() owner to surojit;

